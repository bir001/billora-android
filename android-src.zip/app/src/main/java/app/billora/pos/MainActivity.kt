package app.billora.pos

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.PendingIntent
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothProfile
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothSocket
import android.content.BroadcastReceiver
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Color
import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.print.PrintAttributes
import android.print.PrintManager
import android.provider.MediaStore
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.PermissionRequest
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONArray
import org.json.JSONObject
import java.net.InetSocketAddress
import java.net.Socket
import java.util.UUID
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread

class MainActivity : Activity() {

    private lateinit var web: WebView
    private var printWeb: WebView? = null
    private var fileCb: ValueCallback<Array<Uri>>? = null
    private var camReq: PermissionRequest? = null
    private var pendingPerm: (() -> Unit)? = null
    private var btSocket: BluetoothSocket? = null
    private var btReceiverOn = false
    private var usbRecOn = false
    private var gatt: BluetoothGatt? = null
    private var wChar: BluetoothGattCharacteristic? = null
    private var gattMtu = 23
    @Volatile private var writeLatch: CountDownLatch? = null
    private val spp: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    private val usbAction = "app.billora.pos.USB_PERMISSION"
    private val prefs by lazy { getSharedPreferences("printer", Context.MODE_PRIVATE) }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.WHITE
        window.decorView.systemUiVisibility = android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        web = WebView(this)
        setContentView(web)
        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.mediaPlaybackRequiresUserGesture = false
        s.allowFileAccess = false
        web.addJavascriptInterface(Bridge(), "BilloraNative")
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val host = Uri.parse(BuildConfig.SITE_URL).host
                if (request.url.host == host) return false
                try { startActivity(Intent(Intent.ACTION_VIEW, request.url)) } catch (e: Exception) { }
                return true
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(w: WebView, cb: ValueCallback<Array<Uri>>, p: FileChooserParams): Boolean {
                fileCb?.onReceiveValue(null)
                fileCb = cb
                return try { startActivityForResult(p.createIntent(), 11); true } catch (e: Exception) { fileCb = null; false }
            }
            override fun onPermissionRequest(request: PermissionRequest) {
                runOnUiThread {
                    if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                        request.grant(request.resources)
                    } else {
                        camReq = request
                        requestPermissions(arrayOf(Manifest.permission.CAMERA), 21)
                    }
                }
            }
        }
        web.loadUrl(BuildConfig.SITE_URL)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == 11) {
            fileCb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data))
            fileCb = null
        } else super.onActivityResult(requestCode, resultCode, data)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        val ok = grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED }
        if (requestCode == 21) {
            val r = camReq
            camReq = null
            if (r != null) { if (ok) r.grant(r.resources) else r.deny() }
        } else if (requestCode == 22) {
            val p = pendingPerm
            pendingPerm = null
            if (ok && p != null) p() else emit(JSONObject().put("ev", "bt-error").put("msg", "Bluetooth permission denied"))
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        val js = "(function(){var s=document.getElementById('sheet'),d=document.getElementById('drawer');" +
            "if((s&&s.classList.contains('open'))||(d&&d.classList.contains('open'))){closeAll();return 1}return 0})()"
        web.evaluateJavascript(js) { r ->
            if (r != "1") { if (web.canGoBack()) web.goBack() else finish() }
        }
    }

    private fun emit(o: JSONObject) {
        runOnUiThread { web.evaluateJavascript("window.onNative&&window.onNative(" + o.toString() + ")", null) }
    }

    // ---------- Bluetooth ----------
    private fun btAdapter(): BluetoothAdapter? = (getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter

    private fun needBt(then: () -> Unit) {
        val perms = if (Build.VERSION.SDK_INT >= 31)
            arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
        else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        if (perms.all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }) then()
        else { pendingPerm = then; requestPermissions(perms, 22) }
    }

    private fun devJson(d: BluetoothDevice, paired: Boolean): JSONObject =
        JSONObject().put("ev", "bt-found").put("name", d.name ?: d.address).put("addr", d.address).put("paired", paired)

    private val btReceiver = object : BroadcastReceiver() {
        @SuppressLint("MissingPermission")
        override fun onReceive(c: Context, i: Intent) {
            when (i.action) {
                BluetoothDevice.ACTION_FOUND -> {
                    val d: BluetoothDevice? = if (Build.VERSION.SDK_INT >= 33)
                        i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
                    else @Suppress("DEPRECATION") i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
                    if (d != null && d.name != null) emit(devJson(d, d.bondState == BluetoothDevice.BOND_BONDED))
                }
                BluetoothAdapter.ACTION_DISCOVERY_FINISHED -> emit(JSONObject().put("ev", "bt-done"))
            }
        }
    }

    private val leCb = object : ScanCallback() {
        @SuppressLint("MissingPermission")
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val d = result.device
            if (d.name == null) return
            emit(devJson(d, d.bondState == BluetoothDevice.BOND_BONDED))
        }
    }

    @SuppressLint("MissingPermission")
    private fun startScan() {
        val a = btAdapter()
        if (a == null) { emit(JSONObject().put("ev", "bt-error").put("msg", "Bluetooth not available")); return }
        if (!a.isEnabled) { emit(JSONObject().put("ev", "bt-error").put("msg", "Turn Bluetooth on first")); return }
        a.bondedDevices.forEach { emit(devJson(it, true)) }
        if (!btReceiverOn) {
            val f = IntentFilter().apply {
                addAction(BluetoothDevice.ACTION_FOUND)
                addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED)
            }
            if (Build.VERSION.SDK_INT >= 33) registerReceiver(btReceiver, f, Context.RECEIVER_EXPORTED)
            else registerReceiver(btReceiver, f)
            btReceiverOn = true
        }
        if (a.isDiscovering) a.cancelDiscovery()
        a.startDiscovery()
        try { a.bluetoothLeScanner?.startScan(leCb) } catch (e: Exception) { }
        Handler(Looper.getMainLooper()).postDelayed({
            try { btAdapter()?.bluetoothLeScanner?.stopScan(leCb) } catch (e: Exception) { }
        }, 12000)
    }

    @SuppressLint("MissingPermission")
    private fun connectBt(addr: String) {
        try { btSocket?.close() } catch (e: Exception) { }
        val a = btAdapter() ?: throw Exception("Bluetooth not available")
        try { a.cancelDiscovery() } catch (e: Exception) { }
        val d = a.getRemoteDevice(addr)
        val s = d.createRfcommSocketToServiceRecord(spp)
        try {
            s.connect()
            btSocket = s
        } catch (e: Exception) {
            try { s.close() } catch (x: Exception) { }
            val m = d.javaClass.getMethod("createRfcommSocket", Int::class.javaPrimitiveType)
            val s2 = m.invoke(d, 1) as BluetoothSocket
            s2.connect()
            btSocket = s2
        }
    }

    private fun sendBt(bytes: ByteArray, addr: String) {
        var s = btSocket
        if (s == null || !s.isConnected) { connectBt(addr); s = btSocket }
        val o = s!!.outputStream
        try {
            writeChunks(bytes) { b, off, len -> o.write(b, off, len) }
            o.flush()
        } catch (e: Exception) {
            connectBt(addr)
            val o2 = btSocket!!.outputStream
            writeChunks(bytes) { b, off, len -> o2.write(b, off, len) }
            o2.flush()
        }
    }

    private fun writeChunks(bytes: ByteArray, w: (ByteArray, Int, Int) -> Unit) {
        var i = 0
        while (i < bytes.size) {
            val n = minOf(512, bytes.size - i)
            w(bytes, i, n)
            i += n
            Thread.sleep(6)
        }
    }

    // ---------- Bluetooth LE (GATT) ----------
    @SuppressLint("MissingPermission")
    private fun connectGatt(addr: String) {
        try { gatt?.close() } catch (e: Exception) { }
        wChar = null
        val d = btAdapter()!!.getRemoteDevice(addr)
        val ready = CountDownLatch(1)
        var err: String? = null
        val cb = object : BluetoothGattCallback() {
            override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
                if (newState == BluetoothProfile.STATE_CONNECTED) {
                    if (!g.requestMtu(247)) g.discoverServices()
                } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                    wChar = null
                    if (ready.count > 0L) { err = "Printer disconnected"; ready.countDown() }
                }
            }
            override fun onMtuChanged(g: BluetoothGatt, mtu: Int, status: Int) {
                if (status == BluetoothGatt.GATT_SUCCESS) gattMtu = mtu
                g.discoverServices()
            }
            override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
                var noResp: BluetoothGattCharacteristic? = null
                var withResp: BluetoothGattCharacteristic? = null
                for (sv in g.services) {
                    for (c in sv.characteristics) {
                        val p = c.properties
                        if (noResp == null && (p and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE) != 0) noResp = c
                        if (withResp == null && (p and BluetoothGattCharacteristic.PROPERTY_WRITE) != 0) withResp = c
                    }
                }
                wChar = noResp ?: withResp
                if (wChar == null) err = "No printer write channel found"
                ready.countDown()
            }
            override fun onCharacteristicWrite(g: BluetoothGatt, c: BluetoothGattCharacteristic, status: Int) {
                writeLatch?.countDown()
            }
        }
        gatt = if (Build.VERSION.SDK_INT >= 23) d.connectGatt(this, false, cb, BluetoothDevice.TRANSPORT_LE)
        else d.connectGatt(this, false, cb)
        if (!ready.await(12, TimeUnit.SECONDS)) throw Exception("Connection timed out")
        val e = err
        if (e != null) throw Exception(e)
    }

    @SuppressLint("MissingPermission")
    private fun connectAny(addr: String): String {
        val d = btAdapter()!!.getRemoteDevice(addr)
        if (d.type == BluetoothDevice.DEVICE_TYPE_LE) { connectGatt(addr); return "ble" }
        return try { connectBt(addr); "spp" } catch (e: Exception) { connectGatt(addr); "ble" }
    }

    @Suppress("DEPRECATION")
    private fun sendGatt(bytes: ByteArray, addr: String) {
        if (gatt == null || wChar == null) connectGatt(addr)
        val g = gatt ?: throw Exception("Printer not connected")
        val ch = wChar ?: throw Exception("Printer not connected")
        val noResp = (ch.properties and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE) != 0
        val type = if (noResp) BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE else BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
        val size = maxOf(20, gattMtu - 3)
        var i = 0
        while (i < bytes.size) {
            val n = minOf(size, bytes.size - i)
            val chunk = bytes.copyOfRange(i, i + n)
            if (!noResp) writeLatch = CountDownLatch(1)
            if (Build.VERSION.SDK_INT >= 33) {
                g.writeCharacteristic(ch, chunk, type)
            } else {
                ch.writeType = type
                ch.value = chunk
                g.writeCharacteristic(ch)
            }
            if (noResp) Thread.sleep(12) else writeLatch?.await(3, TimeUnit.SECONDS)
            i += n
        }
    }

    // ---------- USB ----------
    private fun usbMgr() = getSystemService(Context.USB_SERVICE) as UsbManager

    private fun usbReceiverOnce() {
        if (usbRecOn) return
        usbRecOn = true
        val r = object : BroadcastReceiver() {
            override fun onReceive(c: Context, i: Intent) {
                val granted = i.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)
                val id = prefs.getString("pendingUsb", "") ?: ""
                val d = usbMgr().deviceList.values.firstOrNull { it.deviceName == id }
                if (granted && d != null) savePrinter("usb", d.productName ?: "USB printer", d.deviceName)
                else emit(JSONObject().put("ev", "bt-error").put("msg", "USB permission denied"))
            }
        }
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(r, IntentFilter(usbAction), Context.RECEIVER_NOT_EXPORTED)
        else registerReceiver(r, IntentFilter(usbAction))
    }

    private fun sendUsb(bytes: ByteArray, id: String) {
        val m = usbMgr()
        val d: UsbDevice = m.deviceList.values.firstOrNull { it.deviceName == id } ?: throw Exception("USB printer not connected")
        if (!m.hasPermission(d)) throw Exception("USB permission missing")
        val conn = m.openDevice(d) ?: throw Exception("Cannot open USB printer")
        try {
            for (n in 0 until d.interfaceCount) {
                val itf = d.getInterface(n)
                var out: android.hardware.usb.UsbEndpoint? = null
                for (e in 0 until itf.endpointCount) {
                    val ep = itf.getEndpoint(e)
                    if (ep.type == UsbConstants.USB_ENDPOINT_XFER_BULK && ep.direction == UsbConstants.USB_DIR_OUT) out = ep
                }
                if (out == null) continue
                conn.claimInterface(itf, true)
                var i = 0
                while (i < bytes.size) {
                    val len = minOf(16384, bytes.size - i)
                    val chunk = bytes.copyOfRange(i, i + len)
                    if (conn.bulkTransfer(out, chunk, len, 5000) < 0) throw Exception("USB write failed")
                    i += len
                }
                conn.releaseInterface(itf)
                return
            }
            throw Exception("No USB output endpoint found")
        } finally { conn.close() }
    }

    // ---------- LAN ----------
    private fun sendLan(bytes: ByteArray, addr: String) {
        val ip = addr.substringBefore(":")
        val port = addr.substringAfter(":").toIntOrNull() ?: 9100
        val s = Socket()
        try {
            s.connect(InetSocketAddress(ip, port), 4000)
            val o = s.getOutputStream()
            o.write(bytes)
            o.flush()
        } finally { try { s.close() } catch (e: Exception) { } }
    }

    private fun statusJson(): JSONObject {
        val p = try { JSONObject(prefs.getString("p", "") ?: "{}") } catch (e: Exception) { JSONObject() }
        val t = p.optString("type")
        var ok = false
        try {
            when (t) {
                "bt" -> ok = if (p.optString("mode") == "ble") (gatt != null && wChar != null) else (btSocket?.isConnected == true)
                "usb" -> { val m = usbMgr(); ok = m.deviceList.values.any { it.deviceName == p.optString("addr") && m.hasPermission(it) } }
                "lan" -> {
                    val a = p.optString("addr")
                    val s = Socket()
                    try { s.connect(InetSocketAddress(a.substringBefore(":"), a.substringAfter(":").toIntOrNull() ?: 9100), 1500); ok = true }
                    finally { try { s.close() } catch (e: Exception) { } }
                }
            }
        } catch (e: Exception) { ok = false }
        return JSONObject().put("ev", "pstatus").put("ok", ok).put("type", t).put("name", p.optString("name"))
    }

    // ---------- printer store ----------
    private fun savePrinter(type: String, name: String, addr: String, mode: String = "") {
        val j = JSONObject().put("type", type).put("name", name).put("addr", addr).put("mode", mode)
        prefs.edit().putString("p", j.toString()).apply()
        emit(JSONObject().put("ev", "printer").put("name", name))
    }

    private fun parseSize(size: String): PrintAttributes.MediaSize {
        if (size.startsWith("A5")) return PrintAttributes.MediaSize.ISO_A5
        val n = Regex("(\\d+)mm").findAll(size).map { it.groupValues[1].toInt() }.toList()
        if (n.isEmpty()) return PrintAttributes.MediaSize.ISO_A4
        val w = (n[0] * 39.37).toInt()
        val h = if (n.size > 1) (n[1] * 39.37).toInt() else 11000
        return PrintAttributes.MediaSize("billora", "Roll", w, h)
    }

    inner class Bridge {
        @JavascriptInterface fun isNative(): Boolean = true

        @JavascriptInterface fun printer(): String = prefs.getString("p", "") ?: ""

        @JavascriptInterface fun clearPrinter() {
            prefs.edit().remove("p").apply()
            try { btSocket?.close() } catch (e: Exception) { }
            btSocket = null
            try { gatt?.close() } catch (e: Exception) { }
            gatt = null
            wChar = null
        }

        @JavascriptInterface fun scanBt() { runOnUiThread { needBt { startScan() } } }

        @JavascriptInterface fun useBt(addr: String, name: String) {
            runOnUiThread { needBt {
                thread {
                    try { val mode = connectAny(addr); savePrinter("bt", name, addr, mode) }
                    catch (e: Exception) { emit(JSONObject().put("ev", "bt-error").put("msg", "Could not connect: " + (e.message ?: ""))) }
                }
            } }
        }

        @JavascriptInterface fun listUsb(): String {
            val a = JSONArray()
            usbMgr().deviceList.values.forEach {
                a.put(JSONObject().put("id", it.deviceName).put("name", (it.productName ?: "USB device") + " (" + Integer.toHexString(it.vendorId) + ":" + Integer.toHexString(it.productId) + ")"))
            }
            return a.toString()
        }

        @JavascriptInterface fun useUsb(id: String, name: String) {
            runOnUiThread {
                val m = usbMgr()
                val d = m.deviceList.values.firstOrNull { it.deviceName == id }
                if (d == null) { emit(JSONObject().put("ev", "bt-error").put("msg", "USB device not found")); return@runOnUiThread }
                if (m.hasPermission(d)) { savePrinter("usb", name, id); return@runOnUiThread }
                prefs.edit().putString("pendingUsb", id).apply()
                usbReceiverOnce()
                val flags = if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0
                m.requestPermission(d, PendingIntent.getBroadcast(this@MainActivity, 0, Intent(usbAction).setPackage(packageName), flags))
            }
        }

        @JavascriptInterface fun useLan(ip: String, port: Int) {
            thread {
                try {
                    val s = Socket()
                    s.connect(InetSocketAddress(ip, port), 3000)
                    s.close()
                    savePrinter("lan", "$ip:$port", "$ip:$port")
                } catch (e: Exception) { emit(JSONObject().put("ev", "bt-error").put("msg", "Cannot reach $ip:$port")) }
            }
        }

        @JavascriptInterface fun print(b64: String) {
            thread {
                try {
                    val p = JSONObject(prefs.getString("p", "") ?: "{}")
                    val bytes = Base64.decode(b64, Base64.DEFAULT)
                    when (p.optString("type")) {
                        "bt" -> if (p.optString("mode") == "ble") sendGatt(bytes, p.getString("addr")) else sendBt(bytes, p.getString("addr"))
                        "usb" -> sendUsb(bytes, p.getString("addr"))
                        "lan" -> sendLan(bytes, p.getString("addr"))
                        else -> throw Exception("No printer selected")
                    }
                    emit(JSONObject().put("ev", "print").put("ok", true))
                } catch (e: Exception) {
                    emit(JSONObject().put("ev", "print").put("ok", false).put("msg", e.message ?: "error"))
                }
            }
        }

        @JavascriptInterface fun status() { thread { emit(statusJson()) } }

        @JavascriptInterface fun reconnect() {
            runOnUiThread { needBt {
                thread {
                    try {
                        val p = JSONObject(prefs.getString("p", "") ?: "{}")
                        if (p.optString("type") == "bt") {
                            val m = connectAny(p.getString("addr"))
                            prefs.edit().putString("p", p.put("mode", m).toString()).apply()
                        }
                    } catch (e: Exception) { }
                    emit(statusJson())
                }
            } }
        }

        @JavascriptInterface fun disconnect() {
            try { btSocket?.close() } catch (e: Exception) { }
            btSocket = null
            try { gatt?.close() } catch (e: Exception) { }
            gatt = null
            wChar = null
            thread { emit(statusJson()) }
        }

        @JavascriptInterface fun printHtml(html: String, size: String) {
            runOnUiThread {
                val wv = WebView(this@MainActivity)
                printWeb = wv
                wv.webViewClient = object : WebViewClient() {
                    override fun onPageFinished(view: WebView, url: String) {
                        val pm = getSystemService(Context.PRINT_SERVICE) as PrintManager
                        val attrs = PrintAttributes.Builder().setMediaSize(parseSize(size)).setMinMargins(PrintAttributes.Margins.NO_MARGINS).build()
                        pm.print("Billora", view.createPrintDocumentAdapter("Billora"), attrs)
                    }
                }
                wv.loadDataWithBaseURL(null, html, "text/html", "utf-8", null)
            }
        }

        @JavascriptInterface fun saveFile(name: String, mime: String, b64: String) {
            thread {
                try {
                    val v = ContentValues().apply {
                        put(MediaStore.Downloads.DISPLAY_NAME, name)
                        put(MediaStore.Downloads.MIME_TYPE, mime)
                    }
                    val u = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v) ?: throw Exception("Cannot create file")
                    contentResolver.openOutputStream(u)!!.use { it.write(Base64.decode(b64, Base64.DEFAULT)) }
                    emit(JSONObject().put("ev", "saved").put("name", name))
                } catch (e: Exception) {
                    emit(JSONObject().put("ev", "print").put("ok", false).put("msg", "Save failed: " + (e.message ?: "")))
                }
            }
        }
    }
}
