plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "app.billora.pos"
    compileSdk = 34
    defaultConfig {
        applicationId = "app.billora.pos"
        minSdk = 29
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
        buildConfigField("String", "SITE_URL", "\"" + (project.findProperty("siteUrl") ?: "https://bir001.github.io/Billora/") + "\"")
    }
    buildFeatures { buildConfig = true }
    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }
    signingConfigs {
        create("billora") {
            storeFile = file("billora.p12")
            storePassword = "billora123"
            keyAlias = "billora"
            keyPassword = "billora123"
            storeType = "pkcs12"
        }
    }
    buildTypes {
        release {
            signingConfig = signingConfigs.getByName("billora")
            isMinifyEnabled = false
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
